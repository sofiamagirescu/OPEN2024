//
//  AudioTestView.swift
//  Quo
//
//  Created by Calin Gavriliu on 01.08.2024.
//

import SwiftUI

//struct AudioTestView: View {
//    @StateObject private var audioPlayer: AudioPlayer
//    @State private var selectedTrackIndex: Int = 0
//    
//    init(fileNames: [String]) {
//        _audioPlayer = StateObject(wrappedValue: AudioPlayer(fileNames: fileNames))
//    }
//    
//    var body: some View {
//        VStack {
//            Picker("Select Track", selection: $selectedTrackIndex) {
//                ForEach(0..<audioPlayer.players.count, id: \.self) { index in
//                    Text("Track \(index + 1)").tag(index)
//                }
//            }
//            .pickerStyle(SegmentedPickerStyle())
//            .padding()
//            .onChange(of: selectedTrackIndex) {
//                audioPlayer.switchToTrack(at: selectedTrackIndex)
//            }
//        }
//        .padding()
//        .onAppear {
//            audioPlayer.playAllTracks()
//        }
//        .onDisappear {
//            audioPlayer.stopAllTracks()
//        }
//    }
//}
//
//#Preview {
//    AudioTestView(fileNames: ["ploaie1", "ploaie2", "ploaie3", "ploaie4"])
//}
