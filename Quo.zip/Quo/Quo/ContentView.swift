//
//  ContentView.swift
//  Quo
//
//  Created by Calin Gavriliu on 31.07.2024.
//

import SwiftUI

struct ContentView: View {
    
    @EnvironmentObject var audioPlayer: AudioPlayer
    var fileNames: [String]
    
    @Binding var p: Double
    
    @Binding var dropletsAmmount: Int
    @Binding var avrageSpeed: CGFloat
    
    @State private var riverXRotation: Double = 60
    
    var chestieDePeCer: String {
        if p > 36 {
            return "luna"
        } else {
            return "soare"
        }
    }
    
    var body: some View {
        ZStack {
            Color.white
            if p > 36 {
                Color.cyan
                    .opacity(0.2)
            }
            
            let backgorundOpacity = (p-30) / 20
            
            LinearGradient(colors: [
                .black.opacity(backgorundOpacity),
                .black.opacity(backgorundOpacity),
                .black.opacity(backgorundOpacity),
                .black.opacity(backgorundOpacity),
                .black.opacity(backgorundOpacity),
                .indigo
            ], startPoint: .top, endPoint: .bottom)
            
            ScrollViewReader { proxy in
                ScrollView {
                    VStack(spacing: 0) {
                        
                        ZStack {
                            LinearGradient(colors: [
                                .blue.opacity(0.4),
                                p < 36 ? .orange.opacity(0.2) : .indigo.opacity(0.1)
                            ], startPoint: .top, endPoint: .bottom)
                                .saturation(p > 36 ? 1.2 : 2.0)
                            VStack(spacing: -160) {
                                Image(chestieDePeCer)
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: screenWidth / 2.4, height: screenWidth / 2.4)
                                    .shadow(color: .black.opacity(0.2), radius: 24, x: -6, y: 2)
                                    .zIndex(0)
                                    .animation(.smooth, value: chestieDePeCer)
                                CloudsSimulationView(
                                    cloudsCount: 2,
                                    dropletsAmmount: $dropletsAmmount,
                                    avrageSpeed: $avrageSpeed
                                )
                                .zIndex(1)
                            }
                            .padding(.top, 52)
                        }
                        .frame(height: 600)
                        //                .frame(height: 300)
                        .zIndex(2)
                        
                        ZStack {
                            Image("munte")
                                .resizable()
                                .scaledToFit()
                                .frame(width: screenWidth*1.6)
                                .saturation(1.8)
                        }
                        .padding(.vertical, -120)
                        .zIndex(3)
                        
                        ZStack {
                            LinearGradient(colors: [
                                .grass2,
                                .grass1
                            ], startPoint: .top, endPoint: .bottom)
                            .saturation(1.0)
                            .brightness(0.05)
                            .overlay {
                                Image("iarba")
                                    .resizable()
                                    .scaledToFill()
                                    .padding(.top, -(screenWidth / 1.08))
                                    .rotation3DEffect(
                                        Angle(degrees: riverXRotation),
                                        axis: (x: 1, y: 0, z: 0)
                                    )
                                    .opacity(0.2)
                            }
                            .clipped()
                            
                            VStack(spacing: 0) {
                                GIFPlayerView(gifName: "rau", duration: .constant(1))
                                    .frame(width: screenWidth, height: screenWidth*2)
                                    .saturation(2.2)
                            }
                            .padding(.top, -(screenWidth / 1.08))
                            .rotation3DEffect(
                                Angle(degrees: riverXRotation),
                                axis: (x: 1, y: 0, z: 0)
                            )
                            .clipped()
                        }
                        .overlay(alignment: .center) {
                            HStack(spacing: -20) {
                                Image("copac")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(height: 120)
                                    .padding(.bottom, 32)
                                Image("copac")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(height: 120)
                            }
                            .padding(.bottom, 80)
                            .padding(.leading, screenWidth / 2)
                            .zIndex(4)
                        }
                        .overlay(alignment: .center) {
                            Image("copac")
                                .resizable()
                                .scaledToFit()
                                .frame(height: 160)
                                .padding(.bottom, 12)
                                .padding(.trailing, screenWidth / 1.8)
                                .zIndex(4)
                        }
                        //                .frame(height: 560)
                        .zIndex(2)
                        
                        SeaSimulatorView(riverXRotation: .constant(60))
                            .padding(.top, -60)
                            .zIndex(2.5)
                        
                        ZStack(alignment: .center) {
                            LinearGradient(colors: [
                                .indigo,
                                .indigo,
//                                Color(.systemBackground),
//                                Color(.systemBackground)
                            ], startPoint: .top, endPoint: .bottom)
                            //                            .frame(height: 400)
                            
                            VStack {
                                Image(chestieDePeCer)
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: screenWidth / 1.4, height: screenWidth / 1.4)
                                    .padding(.trailing, -(screenWidth / 1.4))
                                    .rotationEffect(.degrees(-12))
                                    .shadow(color: .black.opacity(0.32), radius: 24, x: -6, y: 2)
                                    .animation(.smooth, value: chestieDePeCer)
                                
                                if chestieDePeCer == "soare" {
                                    GIFPlayerView(gifName: "vapori", duration: .constant(1))
                                        .frame(width: screenWidth * 2, height: screenWidth * 2)
                                        .padding(.top, -(screenWidth*0.9))
                                        .opacity(0.2)
                                        .padding(.bottom, -100)
                                }
                            }
                            .frame(width: screenWidth)
                            .padding(.vertical, 60)
                            .padding(.bottom, 400)
                        }
                        .padding(.bottom, -400)
                    }
                    .id("Bottom")
                }
                .onChange(of: p) {
                    if p > 12 {
                        dropletsAmmount = Int(p*1.6)
                        avrageSpeed = p / 1.2
                    } else {
                        dropletsAmmount = 20
                        avrageSpeed = 12
                    }
                    
                    if p > 30 {
                        avrageSpeed = p / 2.5
                    } else {
                        avrageSpeed = 12
                    }
                }
                .onAppear {
                    audioPlayer.loadTracks(fileNames: fileNames)
                    audioPlayer.playAllTracks()
//                    proxy.scrollTo("Bottom")
                }
                .onDisappear {
                    audioPlayer.stopAllTracks()
                }
            }
        }
        .edgesIgnoringSafeArea(.all)
    }
}

#Preview {
//    ContentView(
//        dropletsAmmount: .constant(18),
//        avrageSpeed: .constant(10)
//    )
    
    
    MasterMenuView()
}
