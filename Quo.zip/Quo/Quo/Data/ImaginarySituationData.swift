//
//  ImaginarySituationData.swift
//  Quo
//
//  Created by Calin Gavriliu on 01.08.2024.
//

import Foundation

struct ImaginarySituationExerciseValue {
    let p: Int
    let ev: Double
    let r: Double
    let w: Double
}

let imaginarySituationExerciseValues = [
    ImaginarySituationExerciseValue(p: 1, ev: 0.2, r: 0.2, w: 0.6),
    ImaginarySituationExerciseValue(p: 3, ev: 0.2, r: 0.8, w: 2),
    ImaginarySituationExerciseValue(p: 5, ev: 0.2, r: 1.8, w: 3),
    ImaginarySituationExerciseValue(p: 8, ev: 0.3, r: 3.5, w: 4.3),
    ImaginarySituationExerciseValue(p: 21, ev: 0.3, r: 14.9, w: 5.9),
]
