//
//  LessonHeaderViews.swift
//  Quo
//
//  Created by Calin Gavriliu on 01.08.2024.
//

import SwiftUI

let lessonHeaderViews: [String: AnyView] = [
    "precipitatiile": AnyView(CloudsLessonHeader()),
    "colectarea apei in rau": AnyView(RiverLessonHeader()),
    "scurgerea apei in mare": AnyView(SeaLessonHeader()),
    "evaporarea si condensarea": AnyView(SunHeaderView())
]

struct CloudsLessonHeader: View {
    var body: some View {
        CloudsSimulationView(
            cloudsCount: 2,
            dropletsAmmount: .constant(18),
            avrageSpeed: .constant(10)
        )
        .padding(.top, 96)
    }
}

struct RiverLessonHeader: View {
    var body: some View {
        Image("munte")
            .resizable()
            .scaledToFit()
            .padding(.horizontal, -40)
            .padding(.bottom, 80)
    }
}

struct SeaLessonHeader: View {
    var body: some View {
        SeaSimulatorView(riverXRotation: .constant(60), isHeader: true)
            .frame(width: screenWidth)
            .padding(.bottom, 180)
            .mask(
                LinearGradient(
                    colors: [
                        .red,
                        .red,
                        .clear,
                        .clear
                    ],
                    startPoint: .top,
                    endPoint: .bottom
                )
            )
    }
}

struct SunHeaderView: View {
    var body: some View {
        Image("soare")
            .resizable()
            .scaledToFit()
            .shadow(color: .white.opacity(0.42), radius: 28, y: 24)
            .padding(.horizontal, 80)
            .padding(.bottom, 120)
    }
}

#Preview {
    ZStack {
        Color.blue
        SunHeaderView()
    }
}
