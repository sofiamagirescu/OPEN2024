//
//  LessonsData.swift
//  Quo
//
//  Created by Calin Gavriliu on 01.08.2024.
//

import Foundation

let lessonsData: [Lesson] = [
    Lesson(
        title: "Precipitațiile",
        index: 1,
        headerKey: "precipitatiile",
        bodyText: "Precipitațiile sunt picăturile de apă care cad din nori pe Pământ. Ele pot fi sub formă de ploaie, zăpadă, grindină sau lapoviță. Precipitațiile apar când vaporii de apă din nori se răcesc și se transformă în apă lichidă sau gheață. Când norii devin prea grei, apa cade pe Pământ sub formă de precipitații. Acestea sunt esențiale pentru toate formele de viață, deoarece furnizează apa necesară pentru plante, animale și oameni. Precipitațiile umplu râurile, lacurile și rezervele subterane de apă. În plus, ele ajută la menținerea temperaturii și umidității aerului, contribuind la echilibrul climatic al planetei. Fără precipitații, multe regiuni ar deveni deșerturi aride. Precipitațiile joacă și un rol important în agricultură, asigurând apa necesară culturilor agricole. Prin ciclul anual de ploi, zăpezi și alte forme de precipitații, ecosistemele naturale își păstrează sănătatea și diversitatea.",
        trueOrFalseQuestions: [
            TrueOrFalseQuestion(
                question: "Ploaia este cea mai comună formă de precipitații.",
                correctValue: true
            ),
            TrueOrFalseQuestion(
                question: "Zăpada se formează doar când temperaturile sunt peste punctul de îngheț.",
                correctValue: false
            ),
            TrueOrFalseQuestion(
                question: "Precipitațiile ajută la menținerea temperaturii și umidității aerului.",
                correctValue: true
            )
        ],
        textQuestion: TextBasedQuestion(
            templateText: "___sunt esențiale pentru toate formele de ___deoarece furnizează ___necesară pentru___,animale și oameni. Ele ajută la menținerea temperaturii și ___aerului, contribuind la echilibrul climatic al planetei.",
            answers: [
                "Precipitațiile",
                "viață",
                "apa",
                "plante",
                "umidității"
            ]
        ),
        subLessons: [
            SubLesson(
                title: "Tipuri de Precipitații",
                bodyText: "Precipitațiile pot apărea sub mai multe forme, în funcție de temperatură și condițiile atmosferice. Ploaia este cea mai comună formă de precipitații și apare atunci când temperaturile sunt peste punctul de îngheț. Zăpada se formează când temperaturile sunt sub punctul de îngheț, iar vaporii de apă din atmosferă se transformă direct în cristale de gheață. Grindina apare în timpul furtunilor puternice și constă din bile de gheață, în timp ce lapovița este o combinație de ploaie și zăpadă, întâlnită de obicei în timpul iernii."
            ),
            SubLesson(
                title: "Importanța Precipitațiilor",
                bodyText: "Precipitațiile sunt esențiale pentru toate formele de viață, deoarece furnizează apa necesară pentru plante, animale și oameni. Ele umplu râurile, lacurile și rezervele subterane de apă, asigurând resursele de apă dulce. În plus, ele ajută la menținerea temperaturii și umidității aerului, contribuind la echilibrul climatic al planetei. Precipitațiile joacă și un rol important în agricultură, asigurând apa necesară culturilor agricole. Fără precipitații, multe regiuni ar deveni deșerturi aride."
            )
        ]
    ),
    
    
    
    Lesson(
        title: "Colectarea apei în râu",
        index: 2,
        headerKey: "colectarea apei in rau",
        bodyText: "După ce apa cade pe Pământ ca precipitație, o parte din ea se adună în râuri și pârâuri. Aceste cursuri de apă colectează apa din ploi și zăpezi topite și o transportă spre lacuri și oceane. Râurile sunt ca niște autostrăzi pentru apă, asigurând că aceasta ajunge în locurile unde este nevoie de ea. Pe măsură ce curg, râurile adună și alte materiale, cum ar fi sol și frunze, care sunt importante pentru ecosistemele lor. Râurile nu doar transportă apa, ci oferă și un habitat pentru multe specii de plante și animale. Ele joacă un rol crucial în circuitul apei, transportând apa de pe uscat înapoi în oceane. Râurile pot, de asemenea, modela peisajele prin eroziune și depunerea de sedimente, creând văi și delte. În plus, râurile ajută la filtrarea naturală a apei, eliminând impuritățile și oferind apă curată pentru diverse utilizări.",
        trueOrFalseQuestions: [
            TrueOrFalseQuestion(
                question: "Râurile se formează atunci când apa din precipitații se adună și începe să curgă la vale datorită gravitației.",
                correctValue: true
            ),
            TrueOrFalseQuestion(
                question: "Râurile pot aduna apă doar din ploaie, nu și din zăpada topită.",
                correctValue: false
            ),
            TrueOrFalseQuestion(
                question: "Râurile ajută la menținerea echilibrului hidrologic, redistribuind apa din zonele cu exces de precipitații către cele mai uscate.",
                correctValue: true
            )
        ],
        textQuestion: TextBasedQuestion(
            templateText: "___nu doar transportă ___,ci oferă și un ___pentru multe specii de plante și ___.Ele transportă nutrienți și sedimente care îmbogățesc solurile din jur și susțin viața ___.",
            answers: [
                "Râurile",
                "apa",
                "habitat",
                "animale",
                "plantelor"
            ]
        ),
        subLessons: [
            SubLesson(
                title: "Formarea Râurilor",
                bodyText: "Râurile se formează atunci când apa din precipitații se adună și începe să curgă la vale datorită gravitației. Apa se adună în canale mici, care se unesc pentru a forma râuri mai mari. Pe măsură ce râurile curg, ele pot aduna apă din mai multe surse, inclusiv ploaie, topirea zăpezii și izvoare subterane. Râurile pot fi permanente, curgând tot timpul anului, sau temporare, curgând doar în anumite sezoane sau după ploi abundente."
            ),
            SubLesson(
                title: "Rolul Râurilor în Ecosistem",
                bodyText: "Râurile joacă un rol vital în ecosistemele lor, oferind un habitat pentru multe specii de plante și animale. Ele transportă nutrienți și sedimente care îmbogățesc solurile din jur și susțin viața plantelor. De asemenea, râurile ajută la menținerea echilibrului hidrologic, redistribuind apa din zonele cu exces de precipitații către cele mai uscate. Pe lângă furnizarea de apă potabilă, râurile sunt folosite și pentru irigații în agricultură, producerea de energie hidroelectrică și recreere."
            )
        ]
    ),
    
    
    
    Lesson(
        title: "Scurgerea apei în mare",
        index: 3,
        headerKey: "scurgerea apei in mare",
        bodyText: "Râurile și pârâurile transportă apa colectată până la mări și oceane. Această apă poartă nutrienți și alte materiale care sunt importante pentru viața marină. Pe măsură ce apa curge către mare, ea contribuie la menținerea nivelului apei în oceane și asigură un ciclu continuu de reînnoire. Apa ajunge astfel înapoi în oceane, completând o parte importantă a circuitului apei în natură. Oceanele acoperă o mare parte din suprafața Pământului și sunt esențiale pentru reglarea climatului planetei. De asemenea, ele sunt habitat pentru o varietate enormă de viețuitoare, de la mici planctoni la mari balene. Oceanul joacă un rol crucial în reglarea temperaturii globale și în absorbția dioxidului de carbon, contribuind astfel la echilibrul climatic. În plus, oceanele sunt sursa de hrană pentru multe comunități umane, furnizând pește și alte resurse marine esențiale.",
        trueOrFalseQuestions: [
            TrueOrFalseQuestion(
                question: "Delta unui râu se formează la gura râului, unde acesta se varsă într-o mare sau ocean.",
                correctValue: true
            ),
            TrueOrFalseQuestion(
                question: "Pe măsură ce râurile curg către mare, ele nu transportă niciun fel de sedimente.",
                correctValue: false
            ),
            TrueOrFalseQuestion(
                question: "Poluarea apelor poate avea efecte devastatoare asupra vieții marine.",
                correctValue: true
            )
        ],
        textQuestion: TextBasedQuestion(
            templateText: "Pe măsură ce apa curge către ___,ea contribuie la menținerea nivelului apei în  ___și asigură un ciclu continuu de ___.Poluarea apelor poate duce la moartea peștilor și a altor ___acvatice, afectând___.",
            answers: [
                "mare",
                "oceane",
                "reînnoirire",
                "organisme",
                "biodiversitatea"
            ]
        ),
        subLessons: [
            SubLesson(
                title: "Delta unui Râu",
                bodyText: "Delta este o formă de relief creată la gura unui râu, unde acesta se varsă într-o mare sau ocean. Deltele sunt formate din sedimentele transportate de râu, care se depun pe măsură ce viteza apei scade. Aceste zone sunt extrem de fertile și adăpostesc diverse specii de plante și animale. Deltele sunt, de asemenea, importante pentru pescuit și agricultură datorită solului lor bogat și productiv."
            ),
            SubLesson(
                title: "Impactul Poluării asupra Mărilor",
                bodyText: "Pe măsură ce râurile curg către mare, ele pot transporta și poluanți din activitățile umane, cum ar fi deșeuri industriale, chimicale agricole și gunoaie. Aceste poluanți pot avea efecte devastatoare asupra vieții marine și a calității apei. Poluarea apelor poate duce la moartea peștilor și a altor organisme acvatice, afectând biodiversitatea și sănătatea ecosistemelor marine. Este esențial să protejăm râurile de poluare pentru a menține sănătatea mărilor și a oceanelor."
            )
        ]
    ),
    
    
    
    Lesson(
        title: "Evaporarea și Condensarea",
        index: 4,
        headerKey: "evaporarea si condensarea",
        bodyText: "Apa din mări, lacuri și râuri se evaporă sub acțiunea căldurii de la soare. Evaporarea transformă apa din lichid în vapori care se ridică în atmosferă. Vaporii de apă urcă și formează nori. Acolo, vaporii se răcesc și se condensează, transformându-se în picături mici de apă care formează norii. Acest proces este esențial pentru formarea precipitațiilor, continuând ciclul apei. Fără evaporare și condensare, nu ar exista precipitații, iar Pământul ar deveni un loc foarte uscat. Acest ciclu asigură că apa este distribuită pe toată planeta, menținând viața în toate colțurile ei. Evaporarea și condensarea contribuie și la reglarea temperaturii aerului și la formarea diferitelor tipuri de vreme, cum ar fi ploile torențiale și furtunile. Procesul de evaporare ajută și la răcirea suprafeței Pământului, deoarece energia solară este utilizată pentru transformarea apei în vapori.",
        trueOrFalseQuestions: [
            TrueOrFalseQuestion(
                question: "Evaporarea este procesul prin care apa lichidă se transformă în vapori de apă sub acțiunea căldurii de la soare.",
                correctValue: true
            ),
            TrueOrFalseQuestion(
                question: "Condensarea nu joacă niciun rol în formarea norilor.",
                correctValue: false
            ),
            TrueOrFalseQuestion(
                question: "Evaporarea ajută la răcirea suprafețelor, absorbind căldura în timpul transformării apei în vapori.",
                correctValue: true
            )
        ],
        textQuestion: TextBasedQuestion(
            templateText: "___este procesul prin care vaporii de ___din ___se răcesc și se transformă în picături mici de apă, formând nori. Acest proces este esențial pentru formarea ___,continuând ciclul apei.",
            answers: [
                "Condensarea",
                "apă",
                "atmosferă",
                "precipitațiilor",
            ]
        ),
        subLessons: [
            SubLesson(
                title: "Procesul de Evaporare",
                bodyText: "Evaporarea este procesul prin care apa lichidă se transformă în vapori de apă sub acțiunea căldurii de la soare. Acest proces are loc pe suprafața apelor deschise, cum ar fi mările, lacurile și râurile, dar și pe soluri umede și pe vegetație. Evaporarea este un pas crucial în circuitul apei, deoarece transferă apa din suprafața Pământului în atmosferă, unde poate forma nori și, eventual, precipitații. De asemenea, evaporarea ajută la răcirea suprafețelor, absorbind căldura în timpul transformării apei în vapori."
            ),
            SubLesson(
                title: "Condensarea și Formarea Norilor",
                bodyText: "Condensarea este procesul prin care vaporii de apă din atmosferă se răcesc și se transformă în picături mici de apă, formând nori. Aceasta se întâmplă atunci când aerul cald și umed se ridică și se răcește în altitudinile mai mari. Norii sunt alcătuiți din milioane de picături de apă sau cristale de gheață și joacă un rol esențial în procesul de precipitații. Când aceste picături sau cristale devin suficient de mari, ele cad pe Pământ sub formă de ploaie, zăpadă sau alte tipuri de precipitații, continuând ciclul apei."
            ),
            SubLesson(
                title: "Vântul",
                bodyText: "Vântul joacă un rol important în circuitul apei prin transportul norilor încărcați cu vapori de apă. El mută norii deasupra diferitelor zone ale Pământului, asigurând că precipitațiile ajung în diverse regiuni. Fără vânt, multe locuri ar rămâne uscate, iar ciclul apei nu ar funcționa corect. Vântul este generat de diferențele de temperatură și presiune din atmosferă și ajută la distribuirea uniformă a căldurii și umidității. În plus, vântul contribuie la polenizarea plantelor și la răspândirea semințelor, fiind esențial pentru menținerea ecosistemelor sănătoase. Astfel, vântul nu doar că transportă nori, dar și susține viața pe Pământ în multe moduri diferite. De asemenea, vântul poate influența clima unei regiuni și poate ajuta la formarea diferitelor tipuri de vreme, de la brizele ușoare la uragane puternice. Vânturile globale, cum ar fi alizeele și musonii, joacă un rol crucial în distribuirea apei și a căldurii pe întreaga planetă, influențând în mod direct viața și activitățile umane."
            )
        ]
    ),
]
