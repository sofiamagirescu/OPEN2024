//
//  TextBasedQuestionHelpers.swift
//  Quo
//
//  Created by Calin Gavriliu on 01.08.2024.
//

import Foundation

extension NSRegularExpression {
    func split(template: String) -> [(text: String, punctuation: String?)] {
        var results: [(text: String, punctuation: String?)] = []
        let nsTemplate = template as NSString
        var lastRange = NSRange(location: 0, length: 0)
        
        for match in self.matches(in: template, options: [], range: NSRange(location: 0, length: nsTemplate.length)) {
            let range = match.range(at: 0)
            let text = nsTemplate.substring(with: NSRange(location: lastRange.upperBound, length: range.location - lastRange.upperBound))
            let punctuationRange = match.range(at: 1)
            let punctuation = punctuationRange.location != NSNotFound ? nsTemplate.substring(with: punctuationRange) : nil
            
            results.append((text: text, punctuation: punctuation))
            lastRange = range
        }
        
        let remainingText = nsTemplate.substring(from: lastRange.upperBound)
        results.append((text: remainingText, punctuation: nil))
        
        return results
    }
}

extension String {
    func replacingFirstOccurrence(of target: String, with replacement: String) -> String {
        if let range = self.range(of: target) {
            return self.replacingCharacters(in: range, with: replacement)
        }
        return self
    }
}
