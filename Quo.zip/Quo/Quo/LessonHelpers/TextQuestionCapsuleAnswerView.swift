//
//  TextQuestionCapsuleAnswerView.swift
//  Quo
//
//  Created by Calin Gavriliu on 01.08.2024.
//

import SwiftUI

struct TextQuestionCapsuleAnswerView: View {
    let text: String
    let showIcon: Bool
    
    let removeSpacing: Bool
    
    let removeAnswer: () -> Void
    
    var body: some View {
        HStack {
            Text(text)
            if showIcon {
                Button(action: {
                    withAnimation(.smooth) {
                        removeAnswer()
                    }
                }) {
                    Image(systemName: "x.circle.fill")
                        .foregroundColor(.secondary)
                }
            }
        }
        .padding(.vertical, 6)
        .padding(.leading, 16)
        .padding(.trailing, showIcon ? 10 : 16)
        .background(Color(.systemGray5))
        .foregroundColor(.primary)
        .clipShape(Capsule())
        .font(.headline)
        .padding(.bottom, removeSpacing ? -10 : 9)
        .padding(.top, 12)
    }
}
