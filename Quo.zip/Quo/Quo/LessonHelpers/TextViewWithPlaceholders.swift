//
//  TextViewWithPlaceholders.swift
//  Quo
//
//  Created by Calin Gavriliu on 01.08.2024.
//

import SwiftUI

struct TextViewWithPlaceholders: View {
    let textTemplate: String
    @Binding var placedAnswers: [String?]
    @Binding var tappedAnswers: Set<String>
    
    var body: some View {
        let regex = try! NSRegularExpression(pattern: "___([.,!?;: ]|___)?")
        let segments = regex.split(template: textTemplate)
        
        return VStack(alignment: .leading, spacing: 0) {
            ForEach(0..<segments.count, id: \.self) { i in
                Text(segments[i].text)
                if i < segments.count - 1 {
                    let answerText = placedAnswers[i] ?? "  ...  "
                    let removeSpacing = false
                    
                    TextQuestionCapsuleAnswerView(
                        text: answerText,
                        showIcon: placedAnswers[i] != nil,
                        removeSpacing: removeSpacing
                    ) {
                        removeAnswer(at: i)
                    }
                    .padding(.trailing, 10)
                    .overlay(segments[i].punctuation.map {
                        Text($0)
                            .padding(.bottom, removeSpacing ? -20 : 0)
                    }, alignment: .trailing)
                }
            }
        }
    }
    
    private func removeAnswer(at index: Int) {
        if let answer = placedAnswers[index] {
            tappedAnswers.remove(answer)
            placedAnswers[index] = nil
        }
    }
}
