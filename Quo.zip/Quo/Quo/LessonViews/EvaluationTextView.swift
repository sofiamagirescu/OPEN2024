//
//  EvaluationTextView.swift
//  Quo
//
//  Created by Calin Gavriliu on 31.07.2024.
//

import SwiftUI

struct EvaluationTextView: View {
    
    let question: TextBasedQuestion
    
    @State private var placedAnswers: [String?]
    @State private var tappedAnswers: Set<String> = []
    @Binding var isCorrect: Bool?
    
    init(question: TextBasedQuestion, isCorrect: Binding<Bool?>) {
        self.question = question
        self._isCorrect = isCorrect
        self._placedAnswers = State(initialValue: Array(repeating: nil, count: question.answers.count))
    }
    
    var body: some View {
        HStack(spacing: 0) {
            VStack(alignment: .leading, spacing: 24) {
                
                let filteredAnswers = question.answers.filter { !placedAnswers.contains($0) }
                
                TextViewWithPlaceholders(textTemplate: question.templateText, placedAnswers: $placedAnswers, tappedAnswers: $tappedAnswers)
                    .font(.title3)
                    .padding(.bottom, filteredAnswers.isEmpty ? -16 : 0)
                
                FlowLayout(items: filteredAnswers.shuffled(), spacing: 3, content: { text in
                    ZStack {
                        if !placedAnswers.contains(text) {
                            Button(action: {
                                if !tappedAnswers.contains(text) {
                                    tappedAnswers.insert(text)
                                    withAnimation(.smooth) {
                                        placeAnswer(text)
                                    }
                                }
                            }) {
                                Text(text)
                                    .padding(.vertical, 6)
                                    .padding(.horizontal, 16)
                                    .background(Color.accentColor)
                                    .foregroundColor(.white)
                                    .clipShape(Capsule())
                                    .font(.headline)
                            }
                        }
                    }
                })
            }
            Spacer(minLength: 0)
        }
        .onChange(of: placedAnswers) {
            withAnimation {
                if placedAnswers.contains(nil) {
                    isCorrect = nil
                }
            }
        }
    }
    
    private func placeAnswer(_ answer: String) {
        if let index = placedAnswers.firstIndex(of: nil) {
            placedAnswers[index] = answer
            checkCompletion()
        }
    }
    
    private func checkCompletion() {
        let filledAnswers = placedAnswers.compactMap { $0 }
        if filledAnswers.count == question.answers.count {
            isCorrect = filledAnswers.elementsEqual(question.answers)
        } else {
            isCorrect = nil
        }
    }
}

#Preview {
    ScrollView {
        EvaluationTextView(
            question: TextBasedQuestion(
                templateText: "___sunt esențiale pentru toate formele de ___deoarece furnizează ___necesară pentru___,animale și oameni. Ele ajută la menținerea temperaturii și ___aerului, contribuind la echilibrul climatic al planetei.",
                answers: [
                    "Precipitațiile",
                    "viață",
                    "apa",
                    "plante",
                    "umidității"
                ]
            ),
            isCorrect: .constant(nil)
        )
        .padding(32)
    }
}
