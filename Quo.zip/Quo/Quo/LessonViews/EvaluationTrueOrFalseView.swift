//
//  EvaluationTrueOrFalseView.swift
//  Quo
//
//  Created by Calin Gavriliu on 01.08.2024.
//

import SwiftUI

struct ToggleModifier: ViewModifier {
    var isSelected: Bool
    
    func body(content: Content) -> some View {
        content
            .padding(.horizontal, 10)
            .padding(.vertical, 2)
            .foregroundColor(isSelected ? .white : .primary)
            .background(isSelected ? Color.accentColor : Color.clear)
            .cornerRadius(6)
    }
}

extension View {
    func toggleStyle(isSelected: Bool) -> some View {
        self.modifier(ToggleModifier(isSelected: isSelected))
    }
}

struct EvaluationTrueOrFalseView: View {
    @Binding var selectedValues: [UUID: Bool?]
    
    let question: TrueOrFalseQuestion
    
    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            HStack(alignment: .center) {
                Text("adevarat\nsau fals:")
                    .font(.subheadline.smallCaps())
                Spacer()
                
                
                HStack(spacing: selectedValues[question.id] == nil ? 3 : -1) {
                    Button(action: {
                        withAnimation {
                            selectedValues[question.id] = true
                        }
                    }) {
                        Text("A")
                            .toggleStyle(isSelected: selectedValues[question.id] == true)
                            .padding(.trailing, selectedValues[question.id] == true ? 10 : 0)
                    }
                    
                    Color.primary
                        .frame(width: 1.2, height: 16)
                        .animation(.smooth, value: selectedValues[question.id] == nil)
                    
                    Button(action: {
                        withAnimation {
                            selectedValues[question.id] = false
                        }
                    }) {
                        Text("F")
                            .toggleStyle(isSelected: selectedValues[question.id] == false)
                            .padding(.leading, selectedValues[question.id] == false ? 10 : 0)
                    }
                }
                .font(.title3)
                .bold()
                .padding(.horizontal, 6)
                .padding(.vertical, 4)
                .background(Color(.systemBackground))
                .cornerRadius(6)
                .shadow(color: .accentColor.opacity(0.12), radius: 10, x: 4, y: 2)
                .shadow(color: .black.opacity(0.06), radius: 10, x: 4, y: 2)
                .font(.title3)
                .bold()
            }
            
            Divider()
            
            Text(question.question)
                .font(.title3)
        }
    }
}

#Preview {
    EvaluationTrueOrFalseView(
        selectedValues: .constant([UUID(): nil]),
        question:
        TrueOrFalseQuestion(
            question: "Precipitațiile ajută la menținerea temperaturii și umidității aerului.",
            correctValue: true
        )
    )
    .padding(32)
}
