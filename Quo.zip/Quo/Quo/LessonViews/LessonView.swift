//
//  LessonView.swift
//  Quo
//
//  Created by Calin Gavriliu on 31.07.2024.
//

import SwiftData
import SwiftUI

struct LessonView: View {
    
    @Bindable var lesson: Lesson
    
    @State private var showTestView = false
    
    @State private var expandedSubLesson: UUID?
    
    var body: some View {
        GeometryReader { geometry in
            ScrollView {
                VStack(alignment: .leading, spacing: 32) {
                    ZStack {
                        LinearGradient(colors: [.blue, .clear], startPoint: .top, endPoint: .bottom)
                        
                        lessonHeaderViews[lesson.headerKey]
                            .mask(
                                LinearGradient(
                                    colors: !showTestView
                                    ? [
                                        .red,
                                        .red,
                                        .red,
                                        .clear
                                    ]
                                    : [
                                        .red,
                                        .red,
                                        .clear,
                                        .clear,
                                    ],
                                    startPoint: .top,
                                    endPoint: .bottom
                                )
                            )
                            .padding(.top, -100)
                    }
                    .padding(-32)
                    .frame(height: 560)
                    .padding(.bottom, -280)
                    
                    
                    
                    HStack {
                        VStack(alignment: .leading, spacing: 2) {
                            Text(showTestView ? "Test" : "Lecție")
                                .font(.body.smallCaps())
                            Text(lesson.title)
                                .font(.largeTitle)
                                .bold()
                        }
                        Spacer(minLength: 0)
                    }
                    .padding(.horizontal, 36)
                    .padding(.vertical, 24)
                    .background(Color(.systemBackground).opacity(0.72))
                    .background(Color.blue.opacity(0.18))
                    .cornerRadius(12)
                    .shadow(color: .black.opacity(0.12), radius: 20, x: 6, y: 2)
                    
                    if !showTestView {
                        HStack(alignment: .top, spacing: 12) {
                            Image(systemName: "trophy.circle.fill")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 28, height:28)
                                .padding(2)
                                .foregroundColor(lesson.isTestCompleted ? .green : .primary)
                                .opacity(lesson.isTestCompleted ? 1 : 0.2)
                            Text(lesson.isTestCompleted
                                 ? "Bravo! Ai completat deja aceasta lectie."
                                 : "Rezolva testul acestei lectii pentru a debloca restul hartii!")
                        }
                        .bold()
                        
                        Text(lesson.bodyText)
                        
                    } else {
                        TestView(lesson: lesson, isShown: $showTestView)
                    }
                    
                    Button(action: {
                        withAnimation(.smooth) {
                            showTestView.toggle()
                        }
                    }) {
                        HStack {
                            Spacer(minLength: 0)
                            if showTestView {
                                Text("Anuleaza")
                            } else {
                                Text("Testeaza-ti cunostintele\(lesson.isTestCompleted ? " din nou" : "")!")
                            }
                            Spacer(minLength: 0)
                        }
                        .font(.headline)
                        .padding(.vertical, 6)
                    }
                    .buttonStyle(.bordered)
                    .tint(showTestView ? .secondary : .accentColor)
                    .padding(.top, showTestView ? -16 : 0)
                    
                    if !showTestView && !(lesson.subLessons?.isEmpty ?? true) {
                        Divider()
                        Text("Aprofundare")
                            .font(.title2)
                            .bold()
                        
                        VStack(spacing: 24) {
                            ForEach(lesson.subLessons ?? []) { sublesson in
                                Button(action: {
                                    withAnimation {
                                        if expandedSubLesson == sublesson.id {
                                            expandedSubLesson = nil
                                        } else {
                                            expandedSubLesson = sublesson.id
                                        }
                                    }
                                }) {
                                    let isExpanded = expandedSubLesson == sublesson.id
                                        
                                    VStack(alignment: .leading, spacing: 20) {
                                        HStack {
                                            Text(sublesson.title)
                                                .multilineTextAlignment(.leading)
                                            Spacer()
                                            Image(systemName: "chevron.right")
                                                .rotationEffect(.degrees(isExpanded ? 90 : 0))
                                        }
                                        .font(.headline)
                                        
                                        if isExpanded {
                                            Divider()
                                            
                                            Text(sublesson.bodyText)
                                                .multilineTextAlignment(.leading)
                                        }
                                    }
                                    .padding(24)
                                    .foregroundColor(.primary)
                                    .background(Color(.systemBackground))
                                    .cornerRadius(12)
                                    .shadow(color: .primary.opacity(0.08), radius: 12, x: 6, y: 2)
                                }
                            }
                        }
                    }
                }
                .padding(32)
            }
            .edgesIgnoringSafeArea(.top)
        }
    }
}

#Preview {
    PreviewModel { lesson in
        NavigationStack {
            LessonView(lesson: lesson)
        }
    }
}
