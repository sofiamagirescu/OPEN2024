//
//  TestView.swift
//  Quo
//
//  Created by Calin Gavriliu on 01.08.2024.
//

import SwiftUI

struct TestView: View {
    
    @Binding var isShown: Bool
    
    @State private var viewIndex = 0
    @Bindable var lesson: Lesson
    
    @State private var selectedTrueOrFalseAnswers: [UUID: Bool?] = [:]
    var allTrueOrFalseAnswers: Dictionary<UUID, Bool?>.Values {
        selectedTrueOrFalseAnswers.values
    }
    @State private var shuffledTrueOrFalseQuestions: [TrueOrFalseQuestion] = []
    
    @State private var areTrueOrFalseQuestionsCorrect: Bool? = nil
    @State private var isTextQuestionsCorrect: Bool? = nil
    
    init(lesson: Lesson, isShown: Binding<Bool>) {
        self.lesson = lesson
        self._isShown = isShown
        _selectedTrueOrFalseAnswers = State(initialValue: Dictionary(uniqueKeysWithValues: lesson.trueOrFalseQuestions.map { ($0.id, nil) }))
        _shuffledTrueOrFalseQuestions = State(initialValue: lesson.trueOrFalseQuestions.shuffled())
    }
    
    var body: some View {
        VStack(spacing: 20) {
            ZStack {
                switch viewIndex {
                case 0:
                    VStack(spacing: 24) {
                        ForEach(shuffledTrueOrFalseQuestions) { question in
                            EvaluationTrueOrFalseView(
                                selectedValues: $selectedTrueOrFalseAnswers,
                                question: question
                            )
                            .padding(24)
                            .background(Color(.systemBackground))
                            .cornerRadius(12)
                            .shadow(color: .primary.opacity(0.08), radius: 12, x: 6, y: 2)
                        }
                    }
                    .disabled(areTrueOrFalseQuestionsCorrect ?? false)
                    
                case 1:
                    EvaluationTextView(
                        question: lesson.textQuestion,
                        isCorrect: $isTextQuestionsCorrect
                    )
                    .padding([.horizontal, .bottom], 24)
                    .padding(.top, 8)
                    .background(Color(.systemBackground))
                    .cornerRadius(12)
                    .shadow(color: .primary.opacity(0.08), radius: 12, x: 6, y: 2)
                    .disabled(isTextQuestionsCorrect ?? false)
                    
                default:
                    Text("")
                }
            }
            .padding(.bottom, 12)
            
            if areTrueOrFalseQuestionsCorrect != nil || isTextQuestionsCorrect != nil {
                if areTrueOrFalseQuestionsCorrect ?? false || isTextQuestionsCorrect ?? false {
                    Text("Felicitari! Ai toate raspunsurile corecte")
                        .foregroundColor(.green)
                    
                    if viewIndex == 0 {
                        Button(action: {
                            withAnimation {
                                viewIndex += 1
                                areTrueOrFalseQuestionsCorrect = nil
                            }
                        }) {
                            HStack {
                                Spacer(minLength: 0)
                                Text("Mai departe")
                                Spacer(minLength: 0)
                            }
                            .font(.headline)
                            .padding(.vertical, 6)
                        }
                        .buttonStyle(.bordered)
                        .tint(.accentColor)
                    } else {
                        Button(action: {
                            withAnimation {
                                lesson.isTestCompleted = true
                                isShown = false
                            }
                        }) {
                            HStack {
                                Spacer(minLength: 0)
                                Text("Finalizeaza")
                                Spacer(minLength: 0)
                            }
                            .font(.headline)
                            .padding(.vertical, 6)
                        }
                        .buttonStyle(.bordered)
                        .tint(.accentColor)
                    }
                    
                } else {
                    Text("Hmmm... se pare ca unele raspunsuri sunt gresite. Incearca din nou!")
                        .foregroundColor(.red)
                }
            }
            
            if !allTrueOrFalseAnswers.contains(nil) && areTrueOrFalseQuestionsCorrect == nil && viewIndex == 0 {
                Button(action: {
                    withAnimation(.smooth) {
                        checkTrueOrFalseQuestions()
                    }
                }) {
                    HStack {
                        Spacer(minLength: 0)
                        Text("Verifică")
                        Spacer(minLength: 0)
                    }
                    .font(.headline)
                }
            }
        }
        .onChange(of: selectedTrueOrFalseAnswers) {
            withAnimation {
                areTrueOrFalseQuestionsCorrect = nil
            }
        }
    }
    
    private func checkTrueOrFalseQuestions() {
        areTrueOrFalseQuestionsCorrect = true
        
        for i in lesson.trueOrFalseQuestions {
            if i.correctValue != selectedTrueOrFalseAnswers[i.id] {
                areTrueOrFalseQuestionsCorrect = false
            }
        }
    }
}

#Preview {
    PreviewModel { lesson in
        ScrollView {
            TestView(
                lesson: lesson,
                isShown: .constant(true)
            )
            .padding(32)
        }
    }
}
