//
//  Lesson.swift
//  Quo
//
//  Created by Calin Gavriliu on 01.08.2024.
//

import SwiftUI
import SwiftData

@Model
class Lesson {
    @Attribute(.unique) var id: UUID
    var title: String
    var index: Int
    var headerKey: String
    var bodyText: String
    
    var trueOrFalseQuestions: [TrueOrFalseQuestion]
    var textQuestion: TextBasedQuestion
    
    var isTestCompleted = false
    
    var subLessons: [SubLesson]?
    
    init(
        title: String,
        index: Int,
        headerKey: String,
        bodyText: String,
        trueOrFalseQuestions: [TrueOrFalseQuestion],
        textQuestion: TextBasedQuestion,
        isTestCompleted: Bool = false,
        subLessons: [SubLesson]? = nil
    ) {
        self.id = UUID()
        self.title = title
        self.index = index
        self.headerKey = headerKey
        self.bodyText = bodyText
        self.trueOrFalseQuestions = trueOrFalseQuestions
        self.textQuestion = textQuestion
        self.isTestCompleted = isTestCompleted
        self.subLessons = subLessons
    }
}

@Model
class SubLesson {
    @Attribute(.unique) var id: UUID
    var title: String
    var bodyText: String
    
    var hasBeenRead: Bool
    
    init(title: String, bodyText: String, hasBeenRead: Bool = false) {
        self.id = UUID()
        self.title = title
        self.bodyText = bodyText
        self.hasBeenRead = hasBeenRead
    }
}
