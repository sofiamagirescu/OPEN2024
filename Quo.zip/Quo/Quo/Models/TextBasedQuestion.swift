//
//  TextBasedQuestion.swift
//  Quo
//
//  Created by Calin Gavriliu on 01.08.2024.
//

import Foundation
import SwiftData

@Model
class TextBasedQuestion {
    @Attribute(.unique) var id: UUID
    var templateText: String
    var answers: [String]

    init(templateText: String, answers: [String]) {
        self.id = UUID()
        self.templateText = templateText
        self.answers = answers
    }
}
