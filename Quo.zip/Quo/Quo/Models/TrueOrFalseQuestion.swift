//
//  TrueOrFalseQuestion.swift
//  Quo
//
//  Created by Calin Gavriliu on 01.08.2024.
//

import Foundation
import SwiftData

@Model
class TrueOrFalseQuestion {
    @Attribute(.unique) var id: UUID
    var question: String
    var correctValue: Bool

    init(question: String, correctValue: Bool) {
        self.id = UUID()
        self.question = question
        self.correctValue = correctValue
    }
}
