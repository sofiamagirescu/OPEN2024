//
//  PopulateWithDataView.swift
//  Quo
//
//  Created by Calin Gavriliu on 01.08.2024.
//

import SwiftUI
import SwiftData

struct PopulateWithDataView: View {
    
//    @Environment(\.modelContext) var modelContext
//    @Query var lessons: [Lesson]
    
    var body: some View {
        MasterMenuView()
            .modelContainer(previewContainer)
//            .onAppear {
//                if lessons.isEmpty || lessons.map({ $0.title }) != lessonsData.map({ $0.title }) {
//                    populateInitialData()
//                }
//            }
    }
    
//    private func populateInitialData() {
//        let lessonsToAdd = lessonsData.filter { lessons.map({ $0.title }).contains($0.title) }
//
//        for lesson in lessonsToAdd {
//            modelContext.insert(lesson)
//        }
//    }
}
