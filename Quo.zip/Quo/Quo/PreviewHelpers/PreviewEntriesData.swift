//
//  PreviewEntriesData.swift
//  Quo
//
//  Created by Calin Gavriliu on 1.08.2024.
//

import SwiftData
import Foundation

let previewContainer: ModelContainer = {
    do {
        let container = try ModelContainer(for: Lesson.self, configurations: ModelConfiguration(isStoredInMemoryOnly: true))
        Task { @MainActor in
            let context = container.mainContext
            for lesson in lessonsData {
                context.insert(lesson)
            }
        }
        return container
        
    } catch {
        fatalError("Failed to create container: \(error.localizedDescription)")
    }
}()
