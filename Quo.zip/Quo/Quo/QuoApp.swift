//
//  QuoApp.swift
//  Quo
//
//  Created by Calin Gavriliu on 31.07.2024.
//

import SwiftUI
import SwiftData

@main
struct QuoApp: App {
    var body: some Scene {
        WindowGroup {
            MasterMenuView()
                .modelContainer(previewContainer)
        }
    }
}
