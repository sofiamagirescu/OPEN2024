//
//  FallingWaterDropletsView.swift
//  Quo
//
//  Created by Calin Gavriliu on 31.07.2024.
//

import SwiftUI

struct WaterDroplet: Identifiable {
    var id = UUID()
    var position: CGPoint
    var speed: CGFloat
}

struct FallingWaterDropletsView: View {
    @Binding var dropletsAmmount: Int
    @Binding var avrageSpeed: CGFloat
    
    @State private var droplets: [WaterDroplet] = []
    @State private var timer = Timer.publish(every: 0.02, on: .main, in: .common).autoconnect()

    var body: some View {
        GeometryReader { geometry in
            Canvas { context, size in
                for droplet in droplets {
                    let rect = CGRect(x: droplet.position.x, y: droplet.position.y, width: 8, height: 16)
                    context.fill(Path(ellipseIn: rect), with: .color(.blue))
                }
            }
            .onReceive(timer) { _ in
                updateDroplets(in: geometry.size)
            }
            .onAppear {
                addDroplets(in: geometry.size)
            }
            .onChange(of: dropletsAmmount) { newValue in
                droplets.removeAll()
                addDroplets(in: geometry.size)
            }
            .onChange(of: avrageSpeed) { newValue in
                updateDropletsSpeed()
            }
        }
        .frame(minWidth: 10, minHeight: 10)
        .edgesIgnoringSafeArea(.all)
    }

    private func addDroplets(in size: CGSize) {
        guard size.width > 0 && size.height > 0 else {
            print("Invalid size: \(size)")
            return
        }
        
        for _ in 0..<dropletsAmmount {
            let x = CGFloat.random(in: 0..<size.width)
            let y = CGFloat.random(in: -size.height..<0)
            let speed = CGFloat.random(in: (avrageSpeed - 2)..<(avrageSpeed + 2))
            let droplet = WaterDroplet(position: CGPoint(x: x, y: y), speed: speed)
            droplets.append(droplet)
        }
    }

    private func updateDroplets(in size: CGSize) {
        for index in droplets.indices {
            droplets[index].position.y += droplets[index].speed
            if droplets[index].position.y > size.height {
                droplets[index].position.y = -10
                droplets[index].position.x = CGFloat.random(in: 0..<size.width)
            }
        }
    }
    
    private func updateDropletsSpeed() {
        for index in droplets.indices {
            droplets[index].speed = CGFloat.random(in: (avrageSpeed - 2)..<(avrageSpeed + 2))
        }
    }
}

#Preview {
    ZStack {
        Color.cyan
        FallingWaterDropletsView(
            dropletsAmmount: .constant(32),
            avrageSpeed: .constant(16)
        )
    }
    .edgesIgnoringSafeArea(.all)
}
