//
//  MovingCloudsView.swift
//  Quo
//
//  Created by Calin Gavriliu on 01.08.2024.
//

import SwiftUI

struct Cloud: Identifiable {
    let id = UUID()
    var position: CGPoint
    var speed: CGFloat
    var size: CGFloat
}

struct MovingCloudsView: View {
    @State private var clouds: [Cloud] = []
    let averageSpeed: CGFloat
    let averageSize: CGFloat
    let cloudAmount: Int

    let timer = Timer.publish(every: 0.02, on: .main, in: .common).autoconnect()

    var body: some View {
        GeometryReader { geometry in
            Canvas { context, size in
                guard let uiImage = UIImage(named: "nor"),
                      let cgImage = uiImage.cgImage else {
                    print("Image not found or cannot convert to CGImage")
                    return
                }

                let graphicsImage = Image(uiImage: uiImage)

                for cloud in clouds {
                    let cloudSize = CGSize(width: cloud.size, height: cloud.size * 0.6)
                    let rect = CGRect(origin: cloud.position, size: cloudSize)

                    context.draw(graphicsImage, in: rect)
                }
            }
            .onAppear {
                initializeClouds(size: geometry.size)
            }
            .onReceive(timer) { _ in
                updateClouds(size: geometry.size)
            }
        }
        .edgesIgnoringSafeArea(.all)
    }

    private func initializeClouds(size: CGSize) {
        let verticalPadding: CGFloat = 100
        let horizontalSpacing: CGFloat = size.width / CGFloat(cloudAmount)

        clouds = (0..<cloudAmount).map { index in
            Cloud(
                position: CGPoint(
                    x: CGFloat(index) * horizontalSpacing + CGFloat.random(in: 0...horizontalSpacing),
                    y: CGFloat.random(in: verticalPadding...(size.height - verticalPadding))
                ),
                speed: CGFloat.random(in: averageSpeed * 0.6...averageSpeed * 1.4),
                size: CGFloat.random(in: averageSize * 0.8...averageSize * 1.2)
            )
        }
    }

    private func updateClouds(size: CGSize) {
        let verticalPadding: CGFloat = 100
        let horizontalSpacing: CGFloat = size.width / CGFloat(cloudAmount)

        for index in clouds.indices {
            clouds[index].position.x -= clouds[index].speed
            if clouds[index].position.x < -clouds[index].size {
                clouds[index].position.x = size.width + CGFloat.random(in: 0...horizontalSpacing)
                clouds[index].position.y = CGFloat.random(in: verticalPadding...(size.height - verticalPadding))
                clouds[index].speed = CGFloat.random(in: averageSpeed * 0.8...averageSpeed * 1.2)
                clouds[index].size = CGFloat.random(in: averageSize * 0.8...averageSize * 1.2)
            }
        }
    }
}

#Preview {
    ZStack {
        Color.blue
            .edgesIgnoringSafeArea(.all)
        
        MovingCloudsView(averageSpeed: 12.0, averageSize: 160.0, cloudAmount: 4)
            .frame(height: 300)
    }
}
