//
//  RiverVideoPlayer.swift
//  Quo
//
//  Created by Calin Gavriliu on 31.07.2024.
//

import SwiftUI
import AVKit

struct RiverVideoPlayer: UIViewControllerRepresentable {
    @Binding var playbackSpeed: Double
    var videoURL: URL

    func makeUIViewController(context: Context) -> AVPlayerViewController {
        let player = AVPlayer(url: videoURL)
        player.actionAtItemEnd = .none
        let playerViewController = AVPlayerViewController()
        playerViewController.player = player
        playerViewController.showsPlaybackControls = false
        playerViewController.videoGravity = .resizeAspectFill

        NotificationCenter.default.addObserver(
            context.coordinator,
            selector: #selector(Coordinator.playerItemDidReachEnd(notification:)),
            name: .AVPlayerItemDidPlayToEndTime,
            object: player.currentItem
        )

        return playerViewController
    }

    func updateUIViewController(_ uiViewController: AVPlayerViewController, context: Context) {
        uiViewController.player?.rate = Float(playbackSpeed)
    }

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    class Coordinator: NSObject {
        var parent: RiverVideoPlayer

        init(_ parent: RiverVideoPlayer) {
            self.parent = parent
        }

        @objc func playerItemDidReachEnd(notification: Notification) {
            if let playerItem = notification.object as? AVPlayerItem {
                playerItem.seek(to: .zero, completionHandler: nil)
            }
        }
    }
}
