//
//  CloudsSimulationView.swift
//  Quo
//
//  Created by Calin Gavriliu on 01.08.2024.
//

import SwiftUI

struct CloudsSimulationView: View {
    
    var cloudsCount: Int
    
    @Binding var dropletsAmmount: Int
    @Binding var avrageSpeed: CGFloat
    
    var body: some View {
        VStack(spacing: -160) {
            ZStack {
                HStack(spacing: -32) {
                    ForEach(0 ..< cloudsCount) { item in
                        VStack {
                            if item == 1 && cloudsCount != 1 {
                                Image("nor")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(
                                        width: 160.0 + 20
                                    )
                            } else {
                                Image("nor")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(
                                        width: 160.0 - 20
                                    )
                                    .padding(.bottom, 48)
                            }
                        }
                        .shadow(color: .blue.opacity(0.16), radius: 20, x: 4, y: 2)
                    }
                }
                MovingCloudsView(averageSpeed: 2.0, averageSize: 160.0, cloudAmount: 4)
                    .shadow(color: .blue.opacity(0.16), radius: 20, x: 4, y: 2)
                    .frame(width: screenWidth, height: 300)
                    .mask(
                        LinearGradient(colors: [
                            .clear,
                            .red,
                            .red,
                            .red,
                            .red,
                            .red,
                            .red,
                            .red,
                            .red,
                            .clear
                        ], startPoint: .top, endPoint: .bottom)
                    )
                    .padding(.bottom, 60)
            }
            .zIndex(1)
            
            FallingWaterDropletsView(
                dropletsAmmount: $dropletsAmmount,
                avrageSpeed: $avrageSpeed
            )
            .frame(width: screenWidth / 1.4)
            .mask(
                LinearGradient(
                    colors: [
                        .clear,
                        .red,
                        .red,
                        .red,
                        .clear
                    ],
                    startPoint: .top,
                    endPoint: .bottom
                )
            )
            .zIndex(-2)
        }
    }
}

#Preview {
    CloudsSimulationView(
        cloudsCount: 2,
        dropletsAmmount: .constant(18),
        avrageSpeed: .constant(12)
    )
}
