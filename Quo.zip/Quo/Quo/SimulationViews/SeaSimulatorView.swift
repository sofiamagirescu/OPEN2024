//
//  SeaSimulatorView.swift
//  Quo
//
//  Created by Calin Gavriliu on 01.08.2024.
//

import SwiftUI

struct SeaSimulatorView: View {
    
    @Binding var riverXRotation: Double
    var isHeader = false
    
    var body: some View {
        ZStack(alignment: .top) {
            if !isHeader {
                Ellipse()
                    .frame(width: screenWidth*2, height: 200)
                    .foregroundColor(.blue)
            }
            LinearGradient(
                colors: [.blue, .indigo],
                startPoint: .top,
                endPoint: .bottom
            )
            .padding(.top, 40)
            
            VStack(spacing: 0) {
                GIFPlayerView(gifName: "valuri", duration: .constant(4))
                    .padding(.top, 160)
                    .opacity(0.6)
            }
            .rotation3DEffect(
                Angle(degrees: riverXRotation),
                axis: (x: 1, y: 0, z: 0)
            )
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .padding(.top, -(riverXRotation * 4.35)+120)
            .padding(.vertical, -280)
            .clipped()
            
            GIFPlayerView(gifName: "peste", duration: .constant(2))
                .padding(.top, 160)
                .padding(-32)
            GIFPlayerView(gifName: "peste", duration: .constant(2))
                .padding(.top, -100)
                .padding(-32)
        }
        .frame(width: screenHeight*10, height: 500)
    }
}

#Preview {
    ScrollView {
        SeaSimulatorView(riverXRotation: .constant(60))
    }
}
