//
//  JustifiedText.swift
//  Quo
//
//  Created by Calin Gavriliu on 31.07.2024.
//

import SwiftUI

struct JustifiedText: View {
    let text: String
    let lineHeight: CGFloat

    var body: some View {
        GeometryReader { geometry in
            self.createText(for: geometry.size.width)
        }
    }

    private func createText(for width: CGFloat) -> some View {
        let words = text.split(separator: " ").map(String.init)
        let spaceWidth: CGFloat = " ".width(for: UIFont.systemFont(ofSize: 17))
        
        var lines: [String] = []
        var currentLine = ""
        var currentLineWidth: CGFloat = 0

        for word in words {
            let wordWidth = word.width(for: UIFont.systemFont(ofSize: 17))
            if currentLineWidth + wordWidth + spaceWidth <= width {
                if !currentLine.isEmpty {
                    currentLine += " "
                }
                currentLine += word
                currentLineWidth += wordWidth + spaceWidth
            } else {
                lines.append(currentLine)
                currentLine = word
                currentLineWidth = wordWidth + spaceWidth
            }
        }
        if !currentLine.isEmpty {
            lines.append(currentLine)
        }

        return VStack(alignment: .leading, spacing: 0) {
            ForEach(lines, id: \.self) { line in
                HStack(spacing: 0) {
                    let words = line.split(separator: " ").map(String.init)
                    ForEach(0..<words.count, id: \.self) { index in
                        Text(words[index])
                            .fixedSize()
                        if index < words.count - 1 {
                            Spacer(minLength: 0)
                        }
                    }
                }
                .frame(maxWidth: width, alignment: .leading)
                .frame(height: self.lineHeight)
            }
        }
    }
}

extension String {
    func width(for font: UIFont) -> CGFloat {
        let nsString = self as NSString
        let attributes = [NSAttributedString.Key.font: font]
        return nsString.size(withAttributes: attributes).width
    }
}
