//
//  SafeAreaInsets.swift
//  Quo
//
//  Created by Calin Gavriliu on 01.08.2024.
//

import SwiftUI

struct SafeAreaInsetsKey: EnvironmentKey {
    static let defaultValue: EdgeInsets = EdgeInsets()
}

extension EnvironmentValues {
    var safeAreaInsets: EdgeInsets {
        get { self[SafeAreaInsetsKey.self] }
        set { self[SafeAreaInsetsKey.self] = newValue }
    }
}

struct SafeAreaInsetsModifier: ViewModifier {
    @State private var safeAreaInsets: EdgeInsets = EdgeInsets()
    
    func body(content: Content) -> some View {
        content
            .background(
                GeometryReader { geometry in
                    Color.clear
                        .onAppear {
                            let uiInsets = geometry.safeAreaInsets
                            self.safeAreaInsets = EdgeInsets(
                                top: uiInsets.top,
                                leading: uiInsets.leading,
                                bottom: uiInsets.bottom,
                                trailing: uiInsets.trailing
                            )
                        }
                        .onChange(of: geometry.frame(in: .global)) {
                            let uiInsets = geometry.safeAreaInsets
                            self.safeAreaInsets = EdgeInsets(
                                top: uiInsets.top,
                                leading: uiInsets.leading,
                                bottom: uiInsets.bottom,
                                trailing: uiInsets.trailing
                            )
                        }
                }
            )
            .environment(\.safeAreaInsets, safeAreaInsets)
    }
}

extension View {
    func safeAreaInsets() -> some View {
        self.modifier(SafeAreaInsetsModifier())
    }
}
