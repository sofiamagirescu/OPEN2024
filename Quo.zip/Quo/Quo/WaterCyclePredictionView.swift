//
//  WaterCyclePredictionView.swift
//  Quo
//
//  Created by Calin Gavriliu on 01.08.2024.
//

import CoreML
import SwiftUI
//import UIKit

struct WaterCyclePredictionView: View {
    
    @EnvironmentObject var audioPlayer: AudioPlayer
    
    @Binding var p: Double
    @State private var ev: Double = 0
    @State private var r: Double = 0
    @State private var w: Double = 0
    
    var body: some View {
        VStack(spacing: 24) {
            VStack {
                HStack {
                    Image(systemName: "drop.degreesign.fill")
                    Text("Precipitatii")
                }
                .font(.headline)
                Slider(
                    value: $p,
                    in: 1...50,
                    step: 1
                )
            }
            .padding(24)
            .background(Color(.systemBackground))
            .cornerRadius(12)
            .shadow(color: .primary.opacity(0.12), radius: 12, x: 6, y: 2)
            .onChange(of: p) {
                calculateCycle()
                
//                if p == 50 {
//                    let impactFeedback = UIImpactFeedbackGenerator(style: .medium)
//                    impactFeedback.impactOccurred()
//                }
            }
            .onChange(of: p < 36) {
                if p > 36 {
                    print("ploaie 3")
                    audioPlayer.switchToTrack(at: 1)
                } else {
                    print("ploaie 1")
                    audioPlayer.switchToTrack(at: 0)
                }
            }
            .onAppear {
                calculateCycle()
            }
            
            GeometryReader { geometry in
                HStack(spacing: 0) {
                    Color.blue
                        .frame(width: (ev*geometry.size.width)/p)
                    Color.red
                        .frame(width: (r*geometry.size.width)/p)
                    Color.yellow
                        .frame(width: (w*geometry.size.width)/p)
                }
                .cornerRadius(8)
                .frame(height: 80)
            }
            .padding(.bottom, 20)
            
            VStack(spacing: 18) {
                HStack {
                    Image(systemName: "circle.fill")
                        .foregroundColor(.blue)
                    Text("Evaporare:")
                    Text("\(String(format: "%.0f", (ev / p) * 100))%")
                        .fontWeight(.bold)
                    Spacer(minLength: 0)
                }
                .font(.title3)
                
                Divider()
                
                HStack(alignment: .bottom) {
                    Image(systemName: "circle.fill")
                        .foregroundColor(.red)
                    Text("Scurgeri:")
                    Text("\(String(format: "%.0f", (r / p) * 100))%")
                        .fontWeight(.bold)
                    Spacer(minLength: 0)
                }
                .font(.title3)
                
                Divider()
                
                HStack(alignment: .bottom) {
                    Image(systemName: "circle.fill")
                        .foregroundColor(.yellow)
                    Text("Infiltrare")
                    Text("\(String(format: "%.0f", (w / p) * 100))%")
                        .fontWeight(.bold)
                    Spacer(minLength: 0)
                }
                .font(.title3)
            }
            .multilineTextAlignment(.center)
            .padding(24)
            .background(Color(.systemBackground))
            .cornerRadius(12)
            .shadow(color: .primary.opacity(0.12), radius: 12, x: 6, y: 2)
            
            Image("casa")
                .resizable()
                .scaledToFit()
                .padding(.leading, 42)
                .padding(.trailing, 24)
                .padding(.bottom, 42)
                .padding(.top, 64)
                .frame(width: screenWidth - 64)
                .frame(minHeight: screenHeight / 3.5)
                .background(Color(.systemBackground))
                .cornerRadius(12)
                .shadow(color: .primary.opacity(0.12), radius: 12, x: 6, y: 2)
                .overlay(
                    HStack {
                        Image("sageata-stanga")
                            .resizable()
                            .scaledToFit()
                            .frame(height: 34)
                            .shadow(color: .black.opacity(0.16), radius: 12, x: -4, y: 2)
                            .padding(.top, screenWidth / 6.4)
                        Spacer()
                        VStack {
                            Image("sageata-sus")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 42)
                                .saturation(8.0)
                                .brightness(0.3)
                                .shadow(color: .black.opacity(0.16), radius: 12, x: -4, y: 2)
                            Spacer(minLength: screenWidth / 8)
                            
                            Image("sageata-jos")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 42)
                                .shadow(color: .black.opacity(0.16), radius: 12, x: -4, y: 2)
                                .saturation(1.6)
                                .brightness(0.1)
                        }
                    }
                    .padding(24)
                    .padding(.trailing, 24)
                )
        }
    }
    
    private func calculateCycle() {
        do {
            let config = MLModelConfiguration()
            let model1 = try WValueWaterCyclePrediction(configuration: config)
            let model2 = try EVValueWaterCyclePrediction(configuration: config)

            let wPrediction = try model1.prediction(p: p)
            let wPredictedValue = wPrediction.w
            let evPrediction = try model2.prediction(p: p, w: wPredictedValue)
            let evPredictedValue = evPrediction.ev
            
            let rPredictedValue = p - wPredictedValue - evPredictedValue
            
            w = wPredictedValue
            ev = evPredictedValue
            r = rPredictedValue
        } catch {
            print("e timpul sa bocesti")
        }
    }
}

#Preview {
    ScrollView {
        WaterCyclePredictionView(p: .constant(3))
            .padding(32)
            .environmentObject(AudioPlayer())
    }
}
